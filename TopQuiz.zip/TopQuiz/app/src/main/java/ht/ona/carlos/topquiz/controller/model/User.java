package ht.ona.carlos.topquiz.controller.model;

public class User {
     private String mFirstname;

     public String getFirstname() {
          return mFirstname;
     }

     public void setFirstname(String firstname) {
          mFirstname = firstname;
     }

     @Override
     public String toString() {
          return "User{" +
                  "mFirstname='" + mFirstname + '\'' +
                  '}';
     }
}

